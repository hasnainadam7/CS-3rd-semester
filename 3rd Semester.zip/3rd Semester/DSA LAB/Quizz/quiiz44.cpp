#include <bits/stdc++.h>
using namespace std;


struct Node {
    int val;
    struct Node *left, *right;
};

void helper(vector<int>& res, Node* root, int d)
{
    if (!root)
        return;

    if (d == res.size())
        res.push_back(root->val);

    else


        res[d] = max(res[d], root->val);

    helper(res, root->left, d + 1);
    helper(res, root->right, d + 1);
}
  vector<int> largestValues(Node* root)
{
    vector<int> res;
    helper(res, root, 0);
    return res;
}
Node* newNode(int data)
{
    Node* temp = new Node;
    temp->val = data;
    temp->left = temp->right = NULL;
    return temp;
}


int main()
{


    Node* root = NULL;
    root = newNode(50);
    root->left = newNode(90);
    root->right = newNode(25);
    root->left->left = newNode(33);
    root->left->right = newNode(58);
    root->right->right = newNode(70);

    vector<int> res = largestValues(root);
    for (int i = 0; i < res.size(); i++)
        cout << res[i] << " ";

    return 0;
}
