#include <bits/stdc++.h>
using namespace std;
void print_vector(vector<auto> v){
   cout << "[";
   for(int i = 0; i<v.size(); i++){
      cout << v[i] << ", ";
   }
   cout << "]"<<endl;
}
class TreeNode{
   public:
   int val;
   TreeNode *left, *right;
   TreeNode(int data){
      val = data;
      left = NULL;
      right = NULL;
   }
};
void insert(TreeNode **root, int val){
   queue<TreeNode*> q;
   q.push(*root);
   while(q.size()){
      TreeNode *temp = q.front();
      q.pop();
      if(!temp->left){
         if(val != NULL)
            temp->left = new TreeNode(val);
         else
            temp->left = new TreeNode(0);
         return;
      } else {
         q.push(temp->left);
      }
      if(!temp->right){
         if(val != NULL)
            temp->right = new TreeNode(val);
         else
            temp->right = new TreeNode(0);
         return;
      } else {
         q.push(temp->right);
      }
   }
}
TreeNode *make_tree(vector<int> v){
   TreeNode *root = new TreeNode(v[0]);
   for(int i = 1; i<v.size(); i++){
      insert(&root, v[i]);
   }
   return root;
}
class Solution {
   public:
   vector <int> ans;
   void solve(TreeNode* node, int level = 0){
      if(!node)return;
      if(level == ans.size()){
         ans.push_back(node->val);
      } else {
         ans[level] = max(ans[level], node->val);
      }
      solve(node->left, level + 1);
      solve(node->right, level + 1);
   }
   vector<int> largestValues(TreeNode* root) {
      solve(root);
      return ans;
   }
};
main(){
   vector<int> v = {50,90,25,33,58,NULL,70};
   TreeNode *tree = make_tree(v);
   Solution ob;
   print_vector(ob.largestValues(tree));
}
