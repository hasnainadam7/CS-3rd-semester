#include<conio.h>
#include<iostream>
#include<fstream>
#include<Windows.h>
#include<dos.h>
#include<cctype>
#include<sstream>
#include<string>
using namespace std;
bool check = true;
struct node    //structure of node
{
 char name[20];
 char id[10];
 char address[50];
 char dob[40];
 node *next;
}*head,*lastptr;
int nid;
void add()    //Adds record of client//
{
 node *p;
 p=new node;
 cout<<"Enter name of client:"<<endl;
 gets(p->name);
 fflush(stdin);
 cout<<"Enter id of client:"<<endl;
  gets(p->id);
 fflush(stdin);
 cout<<"Enter address of client:"<<endl;
 cin>>p->address;
 fflush(stdin);
 cout<<"Enter date of birth of client:"<<endl;
 cin>>p->dob;
 fflush(stdin);
 p->next=NULL;

 if(check)
 {
  head = p;
  lastptr = p;
  check = false;
 }
 else
 {
  lastptr->next=p;
  lastptr=p;
 }
 cout<<endl<<"Recored Entered";
 getch();
}
int Id=0;
void search()   //searches record of client//
{
 node *prev=NULL;
 node *current=NULL;
cout<<"Enter id to search:"<<endl;
 cin>>Id;
 prev=head;
 current=head;
 while(current->id!=Id)
 {
  prev=current;
  current=current->next;
 }
 cout<<"\nname: ";
 puts(current->name);
 cout<<"\nid:";
 cout<<current->id;
 cout<<"\naddress:";
 puts(current->address);
 cout<<"\ndate of birth:";
 cout<<current->dob;
 getch();
}
void del()    //deletes record of a client//
{
 node *ptr=NULL;
 node *prev=NULL;
 node *current=NULL;
 int Id;
 cout<<"Enter ID to Delete:"<<endl;
 cin>>Id;
 prev=head;
 current=head;
 while(current->id!=Id)
 {
  prev=current;
  current=current->next;
 }
 prev->next = current->next;
 current->next=NULL;
 delete current;
 cout<<endl<<"Recored Deleted";
 getch();
}

int main()
{
 char x;
 cout<<"\t\t *********** \t\t\t"<<endl;
 cout<<"\t\t ***CLIENT RECORD*** \t\t\t"<<endl;
 cout<<"\t\t *********** \t\t\t"<<endl;
 cout<<"��������������.."<<endl;
 cout<<"�������"<<endl;
 cout<<"��������������������."<<endl;
 cout<<"\n\nPress Any Key To Continue . . . ."<<endl;
 getch();
 do
 {
  system("cls");
  cout<<"1--->Press '1' to add New record:"<<endl;
  cout<<"2--->Press '2' to search a record:"<<endl;
  cout<<"4--->Press '4' to delete a record:"<<endl;
  cout<<"5--->Press '5' to exit:"<<endl;
  x=getch();
  if(x=='1')
  {
   system("cls");
   add();
  }
  else if(x=='2')
  {
   system("cls");
   search();
  }
  else if(x=='3')
  {
   system("cls");
   del();
  }
  else if(x=='4')
  {
   exit(0);
  }
  else
  {
  }
 }while(x != 27);
 getch();
}
