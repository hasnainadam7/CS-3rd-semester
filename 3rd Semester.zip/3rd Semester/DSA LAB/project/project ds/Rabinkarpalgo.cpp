#include<iostream>
#include<fstream>
//#include<ctype.h>
#include<string.h>
#define d 26
static int count=0;
using namespace std;
string is_punctuation(string s){
for (int i = 0, len = s.size(); i < len; i++)
    {
        // check whether parsing character is punctuation and digit or not
        if (ispunct(s[i]) || isdigit(s[i]))
        {
            s.erase(i--, 1);
            len = s.size();
            
        }
        s[i]=tolower(s[i]);
    }
 return s;
}
bool is_matched(string w1){
	fstream f5;
	string w2;
	f5.open("stopwords.txt");
	while(f5>>w2){
	//	cout<<w2<<endl;
		if(w1==w2){
			return 1;
		}
	//return 0;
	}
	f5.close();
}
void textfile1(){
	fstream f1,f3;
	f1.open("Text1.txt"/*,std::ofstream::out|std::ofstream::trunc*/);
	f3.open("Temp1.txt");
	string w1,w2;
	//remove punctuations & digits and special char
	while(getline(f1,w1)){
		w1=is_punctuation(w1);
		f3<<w1<<endl;//after removing and converting to upper case save in temp file
	}
	f1.close();
	//point to start
	f3.seekg(0);
	f1.open("Text1.txt");
	 while(f3>>w2){
    	//cout<<w2<<endl;
    	if(!is_matched(w2)){
    		f1<<w2<<" ";
		//	cout<<w2<<" ";
		}
		//w1=is_matched(w2);
	}
    f3.close(); //NOW TEXTFILE1 has tokanized and stemmed data
}
void textfile2(){
	fstream f1,f3;
	f1.open("Text2.txt"/*,std::ofstream::out|std::ofstream::trunc*/);
	f3.open("Temp2.txt");
	string w1,w2;
	//remove punctuations & digits and special char
	while(getline(f1,w1)){
		w1=is_punctuation(w1);
		f3<<w1<<endl;//after removing and converting to upper case save in temp file
	}
	f1.close();
	//point to start
	f3.seekg(0);
	f1.open("Text2.txt");
	 while(f3>>w2){
    	//cout<<w2<<endl;
    	if(!is_matched(w2)){
    		f1<<w2<<" ";
		//	cout<<w2<<" ";
		}
		//w1=is_matched(w2);
	}
    f3.close(); //NOW TEXTFILE1 has tokanized and stemmed data
}
void search(string pat,string txt,int q){
	int m=pat.length();
	int n=txt.length();
	int i,j,p=0,t=0,h=1;
	for(i=0;i<m-1;i++){
		h=(h*d)%q;
	}
	for(i=0;i<m;i++){
        p=(d*p+pat[i])%q;
        t=(d*t+txt[i])%q;
    }
    for(i=0;i<=n-m;i++){ 
    if ( p == t ){
        for (j = 0; j < m; j++){
            if (txt[i+j] != pat[j]) 
                    break; 
            }
            if (j == m) 
            //cout<<"Pattern found at index "<< i<<endl; 
            count++;
        }
    if ( i < n-m ){
            t = (d*(t - txt[i]*h) + txt[i+m])%q;
            if (t < 0) 
            t = (t + q); 
    }
    }
   // return count;
}
void BruteForce(string pat,string txt){
	int m=pat.length();
	int n=txt.length();
	for(int i=0;i<=n-m;i++){
		int j;
		for(int j=0;j<m;j++){
			if(txt[i+j]!=pat[j]){
				break;
			}
		}
		if(j==m){
			count++;
			//cout<<"Found"<<endl;
		}
	}
}
void RabinKarp(){
	int q=20005;
	fstream f1,f2;
	f1.open("Text1.txt");
	f2.open("Text2.txt");
	string wo1,s1="",wo2;
	int nf1=0,nf2=0;
	while(f1>>wo1){
		s1=s1+" "+wo1;
		nf1++;
	}
	while(f2>>wo1){
		search(wo1,s1,q);
	
		     //	search(pat,txt,q);
		nf2++;
		//BruteForce(wo1,s1);
	}
//	cout<<"\n no of words in file1:"<<nf1;
//	cout<<"\n no of words in file2:"<<nf2;
	//cout<<"\nno of matches"<<s1;
	//cout<<count;
	float plag=0.0;
	
	int total=nf1+nf2;
	count=(2*count)*100;
	plag=(count/total)%100;
	cout<<"\n "<<plag<<" % plagarism between both texts";
	
	f1.close();
	f2.close();
}

int main(){
	//tokanize and stemming textfile1
	textfile1();
	textfile2();
	RabinKarp();
}
