#include <iostream>
using namespace std;

void insert(int i , int *arry, int j, int num ){
		while(j < num){
               arry[j-1] = arry[j];
               j=j+1;
          }
               j=j-1;
          cout << "Deletion of arry" << endl;

	for(i=0 ; i<j; i++)
          {
		cout<< i << "  " << arry[i] << endl;
          }
}
int main () {

int arry[10] = {1,2,3,4,5};
int number = 3, j=4,  i = number, L;

     for(L=0; L<number ; L++)
          {
          cout << "Initial arry are =" << arry[L] << endl;
          }
     if(j <= 0){
          cout << "\n\n";
          cout << "Condition underflow =" << endl;
          }
     else{
          insert(i , arry, j, number);
     }
}
