#include <iostream>
using namespace std;

void insert(int i, int *arry, int j,int k, int number ){
     while(i >= j){
          arry[i] = arry[i-1];
          i--;
	}
          arry[j-1] = k;
          number++;
          cout << "\n\n";

     for(int L=0; L<number ; L++)
     {
          cout << "Final arry are :" << L << "=" << arry[L] << endl;
     }

}

int main () {

int arry[10] = {1,2,3,4,5};
int number = 5, i = number, j=4, k=32, L;

     for(L=0; L<number ; L++)
     {
          cout << "Initial arry are =" << arry[L] << endl;
     }

     if(j >= 10){
          cout << "\n\n";
          cout << "Condition Overflow =" << endl;
     }
     else{
          insert(i , arry, j, k, number);
     }
}
