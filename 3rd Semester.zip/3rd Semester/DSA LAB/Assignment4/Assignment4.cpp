#include <iostream>
#include <algorithm>
#define SIZE(arr) (sizeof(arr) / sizeof(arr[0]))

using namespace std;

void mergeAndSort(int *arr1, int a1, int *arr2, int a2, int *result){
     merge(arr1, arr1 + a1, arr2, arr2 + a2, result);
     sort(result, result + a1 + a2);
}
void displayArray(int *arr, int j){
   for ( int i = 0; i < j; ++i) {
      cout << arr[i] << " ";
   }
   cout << endl;
}
int main(){
   int arr1[] = {1, 3, 5, 7};
   int arr2[] = {2, 4, 6, 8};
   int result[SIZE(arr1) + SIZE(arr1)];
   cout << "First Array list= ";

   displayArray(arr2, SIZE(arr2));
   cout << endl<<"Second Array list= ";

   displayArray(arr1, SIZE(arr2));
   mergeAndSort(arr1, SIZE(arr1), arr2, SIZE(arr2), result);
   cout << endl<<"Merged and sorted array list= ";

   displayArray(result, SIZE(arr1) + SIZE(arr2));
   return 0;
}
