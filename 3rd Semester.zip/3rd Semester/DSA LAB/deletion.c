DELETION WALA

#include<stdio.h>
int main( )
{
	int n, k,j;
	int la[ 4]={2,4,6,8};
	printf("\nEnter no of elements:");
	scanf("%d",&n);
	printf("\nEnter position:");
	scanf("%d",&k);
	j= k;
	while(j<n-1)
	{
		la[j]= la[j+1];
		j=j+1;
	}
    n=n-1;
	printf("\nDELETION DONE\n");
	for(j=0;j<n;j++)
	  {    printf("%d\t",la[j]);
	  }
}
