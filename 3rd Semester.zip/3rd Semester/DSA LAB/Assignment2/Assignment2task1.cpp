#include <iostream>
using namespace std;

int count_Occ(int arry[], int j, int k)
{
    int result = 0;
    for (int i=0; i<j; i++)
        if (k == arry[i])
          result++;
    return result;
}

int main()
{
    int number[] = {2, 2, 1, 8, 2, 8, 7, 3};
    int k = 2;
    int j = sizeof(number)/sizeof(number[0]);
     cout << "Array's:";

    for (int i=0; i < j; i++)
     cout << number[i] <<" ";
     cout <<endl<<"\nNumber of Occurrences of 2:" << count_Occ(number, j, k);

    return 0;
    }
