#include <iostream>

using namespace std;

struct Node
{
    int data;
    Node* link;
};

void insertAtEnd(Node** head_ref, int val)
{
    Node* new_node = new Node();

    Node* last = *head_ref;

    new_node->data = val;

    new_node->link = NULL;

    //If the Linked List is empty, then make the new node as head
    if (*head_ref == NULL)
    {
        *head_ref = new_node;
        return;
    }
    while (last->link != NULL)
    {
        last = last->link;
    }
    last->link = new_node;
}

Node* deleteAtEnd(struct Node* head)
{
    if (head == NULL)
        return NULL;

    if (head->link == NULL) {
        delete head;
        return NULL;
    }

    // Find the second last node
    Node* second_last = head;

    while (second_last->link->link != NULL)
    {
        second_last = second_last->link;
    }

    // Delete last node
    delete (second_last->link);

    // Change next of second last
    second_last->link = NULL;

    return head;
}

void search(Node* head, int x)
{
    Node* temp = head; // Initialize current
    while (temp != NULL)
    {
        if (temp->data == x)
        {
            cout << "\nElement found " << endl;
            exit(0);
        }
        temp = temp->link;
    }
    cout << "\nElement not found" << endl;
}

void displayList(Node* temp)
{
    while (temp != NULL)
    {
        cout << temp->data << " -> ";
        temp = temp->link;
    }
}

void ListEmpty(Node* head, Node* temp)
{
    if (head == NULL)
    {
        cout << "\nList is empty" << endl;
    }
    else
    {
        cout << "List is not empty" << endl;
        while (temp != NULL)
        {
            cout << temp->data << " -> ";
            temp = temp->link;
        }
    }
}

int main()
{
    //Start with the empty list
    Node* head = NULL;

    int ch, ele;

    cout << "Linked List implementation of LIST ADT\n" << endl;

    while (1)
    {
        cout << "\n1). Insert an element at the end." << endl;
        cout << "2). Delete an element at the end." << endl;
        cout << "3). Search an element." << endl;
        cout << "4). Display list." << endl;
        cout << "5). Is List empty." << endl;
        cout << "6). Exit" << endl;

        cout << "\nEnter your choice: ";
        cin >> ch;

        switch (ch)
        {
        case 1:
            cout << "\nEnter the value to be inserted: ";
            cin >> ele;
            insertAtEnd(&head, ele);
            break;

        case 2:
            head = deleteAtEnd(head);
            break;

        case 3:
            cout << "\nEnter the value to be searched: ";
            cin >> ele;
            search(head, ele);
            break;

        case 4:
            cout << "\nCreated Linked list: \n" << endl;
            displayList(head);
            cout << endl;
            break;

        case 5:
            ListEmpty(head, head);
            break;

        case 6:
            exit(0);
            break;
        }
    }

    cout << endl << endl;
    system("pause");


}
