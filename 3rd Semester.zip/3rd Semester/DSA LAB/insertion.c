#include<stdio.h>
int main( )
{
	int n, k,item,j;
	int la[ ]={2,4,6,8};
	printf("\nEnter no of elements");
	scanf("%d",&n);
	printf("\nEnter position:");
	scanf("%d",&k);
	printf("\nEnter element to be inserted:");
	scanf("%d",&item);
	j= n-1;
	while(j>=k)
	{
		la[j+1]= la[j];
		j=j-1;
	}
	la[k]= item;
    n=n+1;
	printf("\nINSERTION DONE\n");
	for(j=0;j<n;j++)
	  {    printf("%d\t",la[j]);
	  }
}
