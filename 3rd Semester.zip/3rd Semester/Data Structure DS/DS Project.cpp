
#include<iostream>
#include<string.h>
#include<fstream>
using namespace std;
string DNA[200];
string RNA[200];
int occurance[21];
	string AminoA[21]={"phenylalanine","leucine","proline","isoleucine","methionine","threonine","valine",
	"alanine","cysteine","tryptophan","tyrosine","terfica","arginine",
	"histidine","glutamine (GluN)","asparagine (AspN)","lysine","glycine","aspartic acid","glutamic acid"};

string ARNA[21]={"UUUUUC","UUAUUGCUUCUCCUACUG","UCUUCCUCAUCGAGUAGC","CCUCCCCCACCG","AUUAUCAUAAUG"
	                  ,"ACUACCACA","ACG","GUUGUCGUAGUG","GCUGCCGCAGCG","UGUUGC","UGG","UAUUAC","UAAUAGUGA","CGUCGCCGACCGAGAAGG"
					  ,"CAUCAC","CAACAG","AAUAAC","AAAAAG","GGUGGCGGAGGG","GAUGAC","GAAGAG"};	 
					  
void getDNA()
{
	fstream file;
	file.open("CheckDNA.txt",ios::in);
	//Getting DNA
	for(int i=0;i<200;i++)
	file>>DNA[i];
	
	file.close(); 
}
void dnaToRna()
{
	//=======================================================
	//           Converting from DNA to RNA
	//=======================================================
	for(int i=0;i<200;i++)
	{
		for(int j=0;j<DNA[i].length();j++)
		{
			if(DNA[i][j]=='A')
			{
				DNA[i][j]='U';
			}else if(DNA[i][j]=='G')
			{
				DNA[i][j]='C';
			}
			else if(DNA[i][j]=='C')
			{
				DNA[i][j]='G';
			}
			else if(DNA[i][j]=='T')
			{
				DNA[i][j]='A';
			}
		}
		RNA[i]=DNA[i];
	}
}
void saveConvertedcodon()
{
	fstream fout;
	fout.open("DNA-RNA.txt",ios::out);
	for(int i=0;i<200;i++)
	{
		for(int j=0;j<DNA[i].length();j++)
		{
			fout<<DNA[i][j];
		}
	}
	fout.close();
}
void findOccurance()
{
		string ARNA1[21]={"UUU","UUA","UCU","CCU","AUU"
	                  ,"ACU","ACG","GUU","GCU","UGU","UGG","UAU","UAA","CGU"
					  ,"CAU","CAA","AAU","AAA","GGU","GAU","GAA"};
	
		
		
	for(int i=0;i<21;i++)
	occurance[i]=0;
	
    for(int i=0;i<RNA[0].length();)
    {
    	for(int k=0;k<21;k++)
    	{
    		  if(ARNA1[k][0]==RNA[0][i] && ARNA1[k][1]==RNA[0][i+1]  && ARNA1[k][2]==RNA[0][i+2])
    		  {
    		  	++occurance[k];
			  }
		}
		i=i+3;
	}
}
void missingAminoAcids()
{
	  cout<<"\n=========================================================";
	cout<<"\n              Missing Amino ACids are: ";
	cout<<"\n=========================================================";
	for(int i=0;i<21;i++)
	{
		if(occurance[i]==0)
		{
			cout<<"\n"<<AminoA[i];
		}
	}
}

void pAminoacids()
{   cout<<"\n=========================================================";
	cout<<"\n              Present Amino ACids are: ";
	cout<<"\n=========================================================";
	for(int i=0;i<21;i++)
	{
		if(occurance[i]==1)
		{
			cout<<"\n"<<AminoA[i];
		}
	}
}
//===============================================================================================
//                           Binary Search Tree
//===============================================================================================
class BSTree
{
	public:
		string str;
		BSTree *Left;
		BSTree *Right;
};
BSTree* GetNewNode(string str)
{
	BSTree *node=new BSTree();
	node->str=str;
	node->Left=0;
	node->Right=0;
	return node;
}

BSTree* Insert(BSTree *root,string str)
{
	if(root==0)
	root=GetNewNode(str);
	else if(str<=root->str)
	{
		root->Left=Insert(root->Left,str);
	}
	else 
	{
		root->Right=Insert(root->Right,str);
	}
	return root;
}
bool search(BSTree* root,string str)
{
	if(root==0) return false;
	else if(str==root->str) return true;
	else if(str<root->str) return search(root->Left,str);
	else  return search(root->Right,str);
}


//===============================================================================================
//                           Binary Search Tree END
//===============================================================================================
int main()
{
	 BSTree *root=0;
    string str;
    int i=0;
    int flag=0;
	 
	 //Getting healthy Human DNA in Tree
	 fstream file;
	 file.open("HHDNA.txt",ios::in);
	 while(!file.eof())
	 {
	 	file>>str;
	 	root=Insert(root,str);
	 	i++;
	 }				  
	 file.close();

	 
	//Checking DNA with healthy Human
	 fstream fin;
	 fin.open("CheckDNA.txt",ios::in);
	 while(!fin.eof())
	 {
	 	fin>>str;
	 	if(search(root,str)==true)
	 	{
	 		continue;
		}else{
			flag=1;
			cout<<"\n\n\n=========================================================";
	 	cout<<"\n                 Unhealthy Human DNA                        ";
	 	cout<<"\n=========================================================\n\n";
	              getDNA();
                  dnaToRna();
                  saveConvertedcodon();
                  findOccurance();
                  pAminoacids();
                  missingAminoAcids();
		}
	 }
	 if(flag==0)
	 {
	 	cout<<"\n\n\n=========================================================";
	 	cout<<"\n                Healthy Human DNA                        ";
	 	cout<<"\n=========================================================\n\n";
	 }
	
     
		 return 0;
}
